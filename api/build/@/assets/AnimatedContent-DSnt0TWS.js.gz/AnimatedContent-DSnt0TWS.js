import{j as o}from"./index-lrQuldHs.js";const e=({children:t})=>o.jsx("div",{className:"w-full overflow-x-auto",children:t});export{e as A};
