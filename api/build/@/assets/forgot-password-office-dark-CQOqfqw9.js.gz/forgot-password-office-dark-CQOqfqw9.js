const a="/@/assets/forgot-password-office-Io3lXaza.jpeg",s="/@/assets/forgot-password-office-Io3lXaza.jpeg";export{a as I,s as a};
