import{j as a}from"./index-lrQuldHs.js";import{L as e}from"./label-D0mdihLM.js";const r=({label:s})=>a.jsx(e,{className:"col-span-4 sm:col-span-2 font-medium text-sm",children:s});export{r as L};
