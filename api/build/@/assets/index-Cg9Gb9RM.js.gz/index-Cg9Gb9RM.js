import{g as o}from"./index-lrQuldHs.js";import{r}from"./index-Dw8nQtKq.js";var s=r();const i=o(s);export{i as o};
